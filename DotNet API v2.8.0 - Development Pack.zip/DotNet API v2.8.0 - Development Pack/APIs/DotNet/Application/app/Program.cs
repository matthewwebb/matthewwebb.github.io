using System;
using System.Collections.Generic;
using System.Text;
using FirstDataBank.DrugServer.Framework;
using FirstDataBank.DrugServer.API;

namespace UAT
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                DrugSystem system = DrugSystemFactory.CreateSystem();


                string disclaimer = system.GetDisclaimer();
                // UK-Specific
                {
                    DrugSystemUK systemUK = (DrugSystemUK)system;
                    string copyright = systemUK.GetCrownCopyright();
                    string bulletin = systemUK.GetBulletin();
                }

                system.Environment.Language = Language.English;

                system.Environment.DrugTerminology = DrugTerminology.MDDF;
                system.Environment.AttributePopulation.PrimaryPreferredName = true;
                system.Environment.AttributePopulation.DrugClass = true;
                system.Environment.AttributePopulation.DrugType = true;
                system.Environment.AttributePopulation.DiscontinuedDate = true;
                // UK-Specific
                {
                    AttributePopulationUK attrUK = (AttributePopulationUK)system.Environment.AttributePopulation;
                    attrUK.Dentist = true;
                }
                system.Environment.PrimaryPreferredNameFormat.AbbrevName = true;
                system.Environment.PrimaryPreferredNameFormat.TallManName = true;
                system.Environment.PicklistOrdering = PicklistOrdering.Option1;


                // Note - you could use a FilterUK here if required
                Filter filter = new Filter();
                filter.DrugClass.Brand = true;
                filter.DrugClass.BrandedGeneric = true;

                Drug[] picklist = system.Navigation.GetDrugsByName("Para*", filter);

                foreach (Drug drug in picklist)
                {
                    Console.WriteLine(drug.PrimaryPreferredName);

                    // UK-Specific
                    {
                        DrugUK drugUK = (DrugUK)drug;

                        drugUK.LoadAllAttributes();

                        Ingredient[] ingredientList = drugUK.GetIngredients();
                        foreach (Ingredient ingredient in ingredientList)
                        {
                            Console.WriteLine("\t {0}", ingredient.Text);
                        }
                    }

                    Console.WriteLine();
                }


                Product[] productList = system.Navigation.GetProductsByName("Para*", filter);

                foreach (Product product in productList)
                {
                    // UK SPecific
                    {
                        ProductUK productUK = (ProductUK)product;
                        // Note:- The Dentist flag is a region-specific property
                        // that may have different values in for example England
                        // and Scotland.
                        bool dentist = productUK.Dentist;
                    }
                }

            }
            catch (FDBApplicationException fdbAppException)
            {
                Console.WriteLine("An FDB Application Exception was thrown");
                Console.WriteLine(fdbAppException.Message);
                Console.WriteLine(fdbAppException.InnerException.Message);
                Console.WriteLine(fdbAppException.StackTrace);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
            }
            Console.ReadLine();
        }
    }
}
